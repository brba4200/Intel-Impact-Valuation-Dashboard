# Intel Impact Monetization Dashboard

Applies TSMC's 2025 Sustainability Impact Valuation method to Intel's GHG, water and health & safety data (2011-2025).

## Run
```
pip install -r requirements.txt
streamlit run app.py
```
Opens at http://localhost:8501. Hover any chart for exact values; all value factors and scenario levers are sliders in the sidebar.

## Files
- app.py: the dashboard (Streamlit + Plotly)
- data/intel_history.csv: Intel 2011-2025 figures with report/page sources
- data/intel_water_sites_2025.csv, data/intel_ghg_sites_2025.csv: Intel 2025 site tables (pp. 60-62)
- data/tsmc_benchmark.csv: TSMC 2021-2025 Integrated P&L lines (NT$ million) and SCC path

Tabs: Overview, Carbon, Water, Health & safety, Scenarios (BAU / Intel targets / Custom), TSMC benchmark, Human dignity, Recommendations, Data & methods.
